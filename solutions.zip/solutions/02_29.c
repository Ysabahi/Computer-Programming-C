#include <stdio.h>

int main()
{

    printf("a is %d\n", 'a');
    printf("b is %d\n", 'b');
    printf("c is %d\n", 'c');
    printf("A is %d\n", 'A');
    printf("B is %d\n", 'B');
    printf("C is %d\n", 'C');
    printf("0 is %d\n", '0');
    printf("1 is %d\n", '1');
    printf("2 is %d\n", '2');
    printf("$ is %d\n", '$');
    printf("* is %d\n", '*');
    printf("+ is %d\n", '+');
    printf("/ is %d\n", '/');
    printf("  is %d\n", ' ');

    return 0;

}
