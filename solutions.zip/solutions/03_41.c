#include <stdio.h>

int main()
{

    int number = 2;

    while (1) {
	printf("%d\n", number);
	number *= 2;
    }
    return 0;

}
