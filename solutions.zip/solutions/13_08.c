/* 
   13_08: PRINT a string
 */
#include <stdio.h>

#define PRINT(string) ( printf("%s", string) )

int main(void)
{

    PRINT("Hello World!\n");
    return 0;
}
